
extern zend_class_entry *phalcon_events_exception_ce;

ZEPHIR_INIT_CLASS(Phalcon_Events_Exception);

