# Change Log

All notable changes to Phalcon Framework will be documented in the version specific changelog file.

To see what we changed in particular framework branch refer to the relevant changelog file.

## Index

- [**`3.2.x`**](CHANGELOG-3.2.md)
- [**`3.1.x`**](CHANGELOG-3.1.md)
- [**`3.0.x`**](CHANGELOG-3.0.md)
- [**`2.0.x`**](CHANGELOG-2.0.md)
- [**`1.x.x`**](CHANGELOG-1.x.md)
